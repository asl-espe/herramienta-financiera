import React from 'react';
import './App.css';
import Navbar from './components/Navbar.jsx';  // Asegúrate de que la ruta es correcta
import { Outlet } from 'react-router-dom';

function App() {
  return (
    <div>
      <Navbar />
      {/* Outlet es donde se renderizan las rutas hijas coincidentes */}
      <Outlet />
    </div>
  );
}

export default App;
