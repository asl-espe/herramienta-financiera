import React from 'react';
import './Dashboard.css';

const Dashboard = () => {
  return (
    <div className="app-container">
      <div className="main-content">
        <h1>Slogan</h1>
        <p>Pequeña descripción del sistema</p>
      </div>
    </div>
  );
};

export default Dashboard;
